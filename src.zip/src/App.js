// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
import React from 'react';
import { UserProvider } from './context/UserContext';
import UserForm from './components/UserForm';
import UserDisplay from './components/UserDisplay';

function App() {
    return (

        <UserProvider>
          
            <div className="container d-flex justify-content-center align-items-center vh-100">
            
            <div className="w-50">
              
                <UserForm />
                <UserDisplay />
            </div>
            </div>
        </UserProvider>
    );
}

export default App;