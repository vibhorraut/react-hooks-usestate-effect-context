import React, { useContext, useEffect } from 'react';
import { UserContext } from '../context/UserContext';

const UserDisplay = () => {
    const { user } = useContext(UserContext);

    useEffect(() => {
        if (user.name && user.email) {
            console.log("User details updated:", user);
        }
    }, [user]);

    return (
        <div className="container mt-4">
            <h3>User Information</h3>
            <p>Name: {user.name}</p>
            <p>Email: {user.email}</p>
        </div>
    );
};

export default UserDisplay;